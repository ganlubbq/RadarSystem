#include "deploy.h"
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <set>

#define _DEBUGHUAWEI0

using namespace std;

//You need to complete the function
void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename)
{
        int nodeNum, linkNum, consumeNum, serverCost;
               
        /**********************************************/
        int **linkInfo, **consumeInfo;
        vector<int> basicInfo;        
	for(int i = 0; i < line_num; i++)
	{
            string temp = topo[i];
            istringstream line(temp);
            string word;
            
            while(line >> word)
                basicInfo.push_back(atoi(word.c_str()));
        }

        nodeNum = basicInfo[0];
        linkNum = basicInfo[1];
        consumeNum = basicInfo[2];
        serverCost = basicInfo[3];
        
        linkInfo = new int*[linkNum];
        for(int i = 0; i < linkNum; i++)
            linkInfo[i] = new int[4];
        for(int i = 0; i < linkNum; i++)
        {
            for(int j = 0; j < 4; j++)
            {
                linkInfo[i][j] = basicInfo[i*4 + j + 4];
            }
        }
            
        consumeInfo = new int*[consumeNum];
        for(int i = 0; i < consumeNum; i++)
            consumeInfo[i] = new int[3];
        for(int i = 0; i < consumeNum; i++)
        {
            for(int j = 0; j < 3; j++)
            {
                consumeInfo[i][j] = basicInfo[i*3 + j + 4 + linkNum * 4];
            }
        }
        /***********************************************/            
#ifdef _DEBUGHUAWEI0
        cout << nodeNum << " " << linkNum << " "
                << consumeNum << " "
                << serverCost << endl;
        cout << linkInfo[0][0] << " " << linkInfo[linkNum - 1][3] << endl;
        cout << consumeInfo[0][0] << " " << consumeInfo[consumeNum - 1][2] << endl;
#endif
        /***********************************************/
        int **adjBandWidth = new int* [nodeNum];
        int **adjRentCost = new int* [nodeNum];
        int **adjDemand = new int* [nodeNum];
        for(int i = 0; i < nodeNum; i++)
        {
            adjBandWidth[i] = new int[nodeNum];
            adjRentCost[i] = new int[nodeNum];            
        }
        for(int i = 0; i < consumeNum; i++)
            adjDemand[i] = new int[nodeNum];
        for(int i = 0; i < nodeNum; i++)
        {
            for(int j = 0; j < nodeNum; j++)
            {
                adjBandWidth[i][j] = 0;
                adjRentCost[i][j] = 0;
            }
        }
        for(int i = 0; i < consumeNum; i++)
        {
            for(int j = 0; j < nodeNum; j++)
                adjDemand[i][j] = 0;
        }    
        for(int i = 0; i < linkNum; i++)
        {
            adjBandWidth[linkInfo[i][0]][linkInfo[i][1]] = linkInfo[i][2];
            adjBandWidth[linkInfo[i][1]][linkInfo[i][0]] = linkInfo[i][2];
            adjRentCost[linkInfo[i][0]][linkInfo[i][1]] = linkInfo[i][3];
            adjRentCost[linkInfo[i][1]][linkInfo[i][0]] = linkInfo[i][3];
        }
        for(int i = 0; i < consumeNum; i++)
        {
            adjDemand[consumeInfo[i][0]][consumeInfo[i][1]] = consumeInfo[i][2];
        }

#ifdef _DEBUGHUAWEI0
        cout << adjBandWidth[46][48] << endl;
        cout << adjRentCost[47][48] << endl;
        cout << adjDemand[8][34] << endl;
        
#endif
        /***************************************************/
        int *nodeBandWidth = new int[nodeNum];
        for(int i = 0; i < nodeNum; i++)
            nodeBandWidth[i] = 0;
        for(int i = 0; i < linkNum; i++)
        {
            nodeBandWidth[linkInfo[i][0]] += linkInfo[i][2];
            nodeBandWidth[linkInfo[i][1]] += linkInfo[i][2];
        }
#ifdef _DEBUGHUAWEI0
        for (int i = 0; i < nodeNum; i++)
            cout << nodeBandWidth[i] << " ";
        cout << endl;
#endif  
        int max = 0;
        int maxindex = 0;
        for(int i = 0; i < nodeNum; i++)
        {
            if(nodeBandWidth[i] > max)
            {
                max = nodeBandWidth[i];
                maxindex = i;
            }
        }
#ifdef _DEBUGHUAWEI0
        cout << maxindex << " " << max << endl;
#endif
        /*******************************************************/
	char * topo_file = (char *)"17\n\n0 8 0 20\n21 8 0 20\n9 11 1 13\n21 22 2 20\n23 22 2 8\n1 3 3 11\n24 3 3 17\n27 3 3 26\n24 3 3 10\n18 17 4 11\n1 19 5 26\n1 16 6 15\n15 13 7 13\n4 5 8 18\n2 25 9 15\n0 7 10 10\n23 24 11 23";

	write_result(topo_file, filename);
        
        /***************************************************/
        /*************************************************/
        for(int i = 0; i < linkNum; i++)
            delete linkInfo[i];
        delete linkInfo;
        for(int i = 0; i < consumeNum; i++)
            delete consumeInfo[i];
        delete consumeInfo;
        /**************************************************/
        for(int i = 0; i < nodeNum; i++)
        {
            delete adjBandWidth[i];
            delete adjRentCost[i];
            delete adjDemand[i];
        }
        delete adjBandWidth;
        delete adjRentCost;
        delete adjDemand;
        /**************************************************/

}

